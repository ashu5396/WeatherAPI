var btnn=document.getElementById("bttn");
btnn.addEventListener('click', function(){
    var countryname=document.getElementById("country").value;
    var appid='&APPID=4e9ae7b7186512aecab7800d286cadf1';
    var halfurl='http://api.openweathermap.org/data/2.5/weather?q=';
    var unit='&units=metric'
var compurl=halfurl+countryname+appid+unit;
var request=new XMLHttpRequest();
request.open('GET',compurl);
request.onload=function(){
    var ourdata=JSON.parse(request.responseText);
    printData(ourdata);
};
request.send();

});
function printData(data)
{
    var printingData="<table style='width:100%' border='1px' cellspacing='0'>"+
    "<tr>"+
      "<th>"+"Name(Entered by You)"+"</th>"+
      "<th>"+"Temperature(in degree celcius)"+"</th>"+ 
      "<th>"+"Pressure(in hpa)"+"</th>"+
      "<th>"+"Humidity"+"</th>"+
    "</tr>"+
    "<tr>"+
      "<td>"+data.name+"</td>"+
      "<td>"+data.main.temp+"&#8451"+"</td>"+ 
      "<td>"+data.main.pressure+"</td>"+
      "<td>"+data.main.humidity+"</td>"+
    "</tr>"+
   
  "</table>";
  document.getElementById("printData").innerHTML=printingData;
}
